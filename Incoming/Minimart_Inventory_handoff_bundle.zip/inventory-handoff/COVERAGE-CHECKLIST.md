# Inventory design coverage checklist

## Frozen screens (must be recognisable, with correct API/permission framing)
- [ ] UI-INV-001 Inventory Overview
- [ ] UI-INV-002 Item Stock Detail
- [ ] UI-INV-003 Stock Movement Explorer
- [ ] UI-INV-004 Stock Count List
- [ ] UI-INV-005 Stock Count Workspace
- [ ] UI-INV-006 Reorder / Low Stock

## Workflows frozen authority requires (cover even where no single frozen screen owns them)
- [ ] Current stock view by item/store, with batch where configured (ties to DEC-INV-004)
- [ ] Stock movement history with source document, direction, quantity, running/contextual balance
- [ ] Manual stock adjustment (reason, user, value where permitted) — immutable once posted, correction via new document
- [ ] Opening stock — controlled, audited posting (DEC-INV-008, PROPOSED mechanism; do not assert a frozen lifecycle beyond "controlled and audited")
- [ ] Stock count: list → workspace → expected/counted/variance → posted count → adjustment linkage (DEC-INV-003 concurrency OPEN — do not pick lock vs snapshot)
- [ ] Inventory valuation using WAC (DEC-INV-001 RESOLVED) — but valuation **report** itself is Reporting-owned per DEC-INV-009; Inventory module screens may show current WAC-derived value, not a full report
- [ ] Negative stock handling — Phase-1 default BLOCK (DEC-INV-010); show as blocked/exceptional, not as a normal state
- [ ] Batch/expiry states where tracking is enabled — no invented FEFO or expiry-window policy (DEC-INV-005 OPEN)
- [ ] Low-stock/reorder flagging — threshold ownership OPEN (DEC-INV-007); show the basis as undefined, not a fabricated number

## States (same screen-state contract used by every approved package)
- [ ] LOADING, READY, EMPTY, VALIDATION_ERROR, PERMISSION_DENIED, CONFLICT
- [ ] LOCAL_CLOUD_OFFLINE (local inventory data continues), STORE_NODE_UNREACHABLE (posting blocked, distinct from cloud outage)
- [ ] INCOMPATIBLE_CLIENT
- [ ] RECOVERY_REQUIRED / safe-retry for adjustment, count-finalize, and opening-stock posting commands

## Money, quantity, country
- [ ] Decimal-string money end to end; quantity respects Item-UoM precision
- [ ] No invented tax recoverability (DEC-PUR-006 VERIFY) shown as settled
- [ ] Country-specific fields only from verified capability metadata

## Responsive / accessibility (match the bar already met by Reporting/Accounting)
- [ ] 1280×720, 1366×768, 1368×800, 1920×1080 — no page-level horizontal scroll, no clipped quantity/money columns
- [ ] Labelled controls, semantic tables with captions/column headers, visible focus, dialog focus trap+restore, status not colour-only, 4.5:1 contrast minimum

## Package format (match the established pattern)
- [ ] `MiniMartInventory.dc.html` + real `support.js`; contiguous screen IDs; unique titles/state mappings; every screen instantiates
- [ ] Grouped canvas pages importing the source live (no duplicated screen logic) + package index
- [ ] Export manifest with SHA-256 per file, screen count, grouping, and an honest statement of what was/wasn't verified
- [ ] Archive name convention: `MiniMart_Inventory_ClaudeDesign_Source.zip`
