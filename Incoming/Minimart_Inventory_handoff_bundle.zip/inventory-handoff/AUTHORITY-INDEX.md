# Frozen Inventory authority — exact paths

All paths are relative to the MiniMart repository root as mounted in this session
(`MiniMart/...`). Hashes were not computed for these repository files in this pass
(see STATUS-AND-GAP-REPORT.md) — Claude Code should hash them at integration time
against its own git-verified checkout.

## Business/functional (frozen v1.0)
- `docs/specifications/01-business-and-functional/docs/02-functional/07-inventory/` — Inventory FRS section (BR-INV-xxx requirements referenced throughout the Decision Register as BR-INV-006, 007, 009).
- `docs/specifications/01-business-and-functional/docs/02-functional/DECISION-REGISTER.md` — frozen decision register (v0.9 consolidated); see DECISIONS-AND-GAPS.md in this bundle for the Inventory-relevant extract.
- `docs/specifications/01-business-and-functional/docs/02-functional/FRS.md`, `TRACEABILITY.md` — full FRS and requirement traceability.

## Domain model (frozen v1.0)
- `docs/specifications/02-domain-model/` — InventoryPosition, stock ledger, WAC costing rules; domain seam matrix (DEC-INV-003/004/005/007/008 treatments).

## Database (frozen v1.2)
- `docs/specifications/03-database-model/` — stock ledger schema, immutability constraints.
- `database/migrations/0001_v1_2_frozen_baseline.sql`, `database/migrations/manifest.json` — frozen baseline migration.

## Architecture (frozen v1.0)
- `docs/specifications/04-architecture/` — read/query architecture (the same Class A/B query boundary used by Reporting applies to Inventory's own screens).

## API contracts (frozen v1.0)
- `docs/specifications/05-api-contracts/` — Inventory module API operations (stock position, movement, adjustment, count, valuation endpoints), idempotency/concurrency/recovery contract (shared with all modules).

## UI specification (frozen v1.0) — Inventory screens
- `docs/specifications/06-ui-specification/screens/UI-INV-001-inventory-overview.md`
- `docs/specifications/06-ui-specification/screens/UI-INV-002-item-stock-detail.md`
- `docs/specifications/06-ui-specification/screens/UI-INV-003-stock-movement-explorer.md`
- `docs/specifications/06-ui-specification/screens/UI-INV-004-stock-count-list.md`
- `docs/specifications/06-ui-specification/screens/UI-INV-005-stock-count-workspace.md`
- `docs/specifications/06-ui-specification/screens/UI-INV-006-reorder-low-stock.md`
- Cross-cutting UI contracts also apply (same as used for the approved Reporting/Accounting packages): screen-state contract, command/recovery contract, money/quantity contract, country-capability matrix, responsive/keyboard/accessibility contracts, error-message standard — all under `docs/specifications/06-ui-specification/` (see the `02-UI-*`, `07`–`14` numbered docs already extracted for Reporting as a model for what to extract for Inventory).

## Backlog
- `docs/backlog/docs/04-BACKLOG-CATALOG.md` — Inventory backlog items (EPIC covering UI-INV-001..006; exact MM-### IDs not confirmed in this pass — Claude Code should extract the verbatim EPIC entry as was done for Reporting's EPIC-07).

## Agent conduct / handoff process
- `AGENTS.md` (repo root) — conduct contract.
- `docs/project-status/CURRENT-STATE.md` — navigation aid (read in this pass; confirms Inventory manifest status `draft`, screenCount `null`, no registered source).
- `docs/design/README.md` (`19-design-handoff-README.md` equivalent) — design handoff flow and manifest schema.
- `docs/design/design-manifest.schema.json` — manifest schema.
- `docs/design/inventory/design-manifest.json` — current Inventory manifest (read in full; reproduced in STATUS-AND-GAP-REPORT.md).

## Approved visual references (for visual consistency)
- `docs/design/accounting/` → `MiniMartAccountingLite.dc.html`, SHA-256 `ebe8ca7f38b9b9d5cd9c16fed421bfe5f5863653ec9478a081d368d2bb9df12e` — `approved-visual-reference`.
- Other approved packages per `CURRENT-STATE.md`: Procurement (`0bf23d77e0d404c99c146b78eba3141de8bc47cc21e9cc8835ffa6091e21951d`), Customers + Credit (`593adaec60d84d384fdc2947a1ba7d169f8ec8eb21d34373fb814ee662259d7c`), Cash / Business Day (`a0d9df668213a9a562bd0fefec9198274c57931b7c6f79da59b87554aee55fee`) — all `approved-visual-reference`.
- `docs/design/back-office/` — Back Office, `review-ready` (not yet approved), design-system base.
