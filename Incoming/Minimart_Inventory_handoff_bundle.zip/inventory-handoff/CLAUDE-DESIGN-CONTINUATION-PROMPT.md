# Ready-to-paste prompt for the Claude Design project

---

Continue the MiniMart Inventory module in this existing Claude Design project.

This project already contains an unregistered, unapproved Inventory build:
`MiniMartInventory.dc.html`, five grouped pages (`MiniMart INV - Foundation & List`,
`Item & Movements`, `Adjustments & Opening Stock`, `Stock Count`, `Design System &
Docs`), a package index (`MiniMart Inventory Mockups.dc.html`), and parallel
print-ready `INV Print -` variants. Treat this as the starting point to refine and
complete, not as something to rebuild from scratch — unless inspection shows it
conflicts with frozen authority, in which case fix only the conflicting parts.

Read the attached handoff bundle's `AUTHORITY-INDEX.md`, `DECISIONS-AND-GAPS.md`,
`COVERAGE-CHECKLIST.md`, and `STATUS-AND-GAP-REPORT.md` first. Frozen requirements and
the Decision Register govern behaviour; this bundle's own status report is honest
about what could and couldn't be verified from the Claude Design side (no git access)
— treat any claim there about commit hashes or file counts as unverified until you
confirm it yourself.

Cover UI-INV-001 through UI-INV-006, plus the workflows frozen authority requires:
current stock (with batch where configured), stock movement history with running
balance, manual adjustment, controlled/audited opening stock, stock count (list →
workspace → variance → posted, with concurrency policy left OPEN per DEC-INV-003),
WAC-based valuation display (the full valuation *report* is Reporting-owned per
DEC-INV-009), negative-stock blocking (Phase-1 default, DEC-INV-010), and batch/expiry
states with no invented FEFO policy (DEC-INV-005 OPEN) or reorder threshold
(DEC-INV-007 OPEN). Preserve immutable posted stock-ledger facts, exact quantities
(Item-UoM precision) and exact decimal-string money, authorization based on actual API
capability data (not just role labels), and the safe-retry/recovery pattern already
used in the approved Accounting-Lite and Cash/Business Day packages for any posting
command (adjustment, count finalize, opening-stock post).

Use the approved Back Office shell and the approved Accounting-Lite package
(`MiniMartAccountingLite.dc.html`) as the visual reference for shell, tokens,
typography, spacing, table/status-chip/note-box patterns — same as every other
approved MiniMart package in this project. Historical Inventory PDFs in the attached
repo's `Mockups/` folder are unapproved visual input only; do not treat them as
authoritative or reverse-engineer missing source from them.

Keep every open decision (DEC-INV-003/004/005/007/008, DEC-POS-003, DEC-PUR-006,
DEC-COM-002) visibly qualified with the same OPEN/VERIFY/PROPOSED/RESOLVED/GAP marker
convention already used in the Accounting-Lite and Reporting packages. Do not resolve
any of them. MM-007 (printer spike) stays PENDING and DEC-HW-001 stays OPEN — no
screen may claim hardware-validated printing.

Deliver: refined/completed `MiniMartInventory.dc.html`, its grouped pages and index,
an export manifest (`INVENTORY-EXPORT-MANIFEST.txt`) with SHA-256 for every packaged
file computed from the final bytes, a requirement-to-screen traceability table, and an
honest statement of what was and wasn't rendered/verified at the four required
viewports (1280×720, 1366×768, 1368×800, 1920×1080). Status stays `review-ready`, not
approved, until the owner reviews it visually — this package only becomes
`approved-visual-reference` through that separate step, same as the other modules.

Do not commit, push, or register this in the repository — that integration step
belongs to Claude Code, which will copy the approved source into
`docs/design/inventory/source/`, update `docs/design/inventory/design-manifest.json`,
and run the repository's render/validation gates.

---
