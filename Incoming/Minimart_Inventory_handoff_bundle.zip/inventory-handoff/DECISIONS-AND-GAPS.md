# Inventory — open decisions and authority gaps (do not resolve; qualify visibly)

Reproduced from the frozen Decision Register / Decision Seam Matrix as read earlier
in this project's work on the Reporting package (same frozen documents govern both).

| ID | Status | What is undecided | Affects |
| --- | --- | --- | --- |
| DEC-INV-001 | RESOLVED | Moving weighted-average cost (WAC) per Item per Store. | Inventory valuation everywhere |
| DEC-INV-002 | RESOLVED for Phase 1 | Negative stock blocked initially; later configurable modes need separate approval. | Negative-stock handling |
| DEC-INV-003 | OPEN | Stock-count concurrency: scope lock vs snapshot/movement reconciliation. | Stock Count screens (UI-INV-004/005) |
| DEC-INV-004 | OPEN | Batch physical depletion policy. | Batch-aware stock views |
| DEC-INV-005 | OPEN | Expiry/FEFO behaviour. | Batch/expiry states |
| DEC-INV-007 | OPEN | Low-stock/reorder threshold ownership. | UI-INV-006 Reorder/Low Stock |
| DEC-INV-008 | PROPOSED | Opening stock through controlled, audited posting. | Opening Stock workflow |
| DEC-INV-009 | RESOLVED | Inventory valuation report belongs in Phase-2 Reporting (not Inventory module screens themselves). | Valuation report ownership |
| DEC-INV-010 | RESOLVED | Phase-1 default negative-stock behaviour is BLOCK under the initial WAC baseline. | Negative stock |
| DEC-POS-003 | VERIFY / OPEN | Expired-stock sale default/exception requires operational/legal validation. | Batch-aware POS + Inventory batch/expiry views |
| DEC-PUR-006 | RESOLVED + VERIFY | WAC formula frozen; recoverable/non-recoverable tax classification needs verified country/accounting policy. | Inventory valuation, acquisition cost |
| DEC-COM-002 | OPEN | Document-number scope (company/store/type) — affects adjustment/count document numbering. | Stock adjustment, count documents |

## Authority gaps (no decision ID)
- Exact Inventory API operation IDs/paths were not individually extracted in this
  pass (unlike Reporting's API-RPT-00x) — Claude Code should pull the verbatim
  operation list from `docs/specifications/05-api-contracts/` for stock position,
  movement, adjustment, count and opening-stock endpoints.
- Exact Inventory backlog item IDs (MM-###) were not confirmed in this pass.
- Permission codes for Inventory beyond whatever base read/write pattern the API
  contracts define were not independently confirmed; do not invent permission codes
  not present in the frozen contracts (same rule as every other module in this
  project).
- MM-007 (printer spike) remains **PENDING** — no physical hardware validation. Any
  print-related Inventory screen (e.g. count sheets, adjustment slips) must not claim
  hardware-validated printing.
- DEC-HW-001 (printer command/interface baseline) remains **OPEN**.

## Preserve, do not invent
- Immutable posted stock-ledger facts — no editing a posted movement/adjustment/count
  after posting; corrections are new documents, not edits.
- Exact quantity (Item-UoM precision) and exact decimal-string money (same contract as
  every other approved package: no JS binary float).
- Authorization — only show actions the API capability/permission data actually
  allows; role labels guide navigation only.
- Recovery — safe-retry/idempotency pattern for any Inventory posting command
  (adjustment, count finalize, opening-stock post), matching the pattern already used
  in the approved Accounting-Lite and Cash/Business Day packages (outcome unknown →
  check status → retry safely, no duplicate effect).
