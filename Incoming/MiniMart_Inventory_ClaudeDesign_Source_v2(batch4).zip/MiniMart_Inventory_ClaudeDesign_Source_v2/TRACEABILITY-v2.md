# MiniMart Inventory — Traceability (all 67 screens)

Coverage classification per screen:
- DEMONSTRATED — a real, interactive control drives visible state change on screen
  (e.g. a real `<input>`/`<select>` that can be focused and typed into).
- STATIC ILLUSTRATION — the screen shows a specific, labelled example state with
  real data, but the control shown does not recompute/branch live (e.g. New
  Adjustment's quantity field is real and focusable but typing a new value does not
  recompute the preview or downstream BLOCK decision).
- DESIGN INTENT — a dashed/annotated note or marker describing an authority
  dependency, open decision, or boundary; not a rendered product state.
- UNRESOLVED GAP — the screen exists but a cited requirement/decision it touches has
  no frozen mechanism, so the screen deliberately stops short of asserting behavior.

No screen below claims to have been rendered or keyboard-tested in a live browser
this session; "DEMONSTRATED" means real, focusable, labelled controls exist in the
final source with real onKey/onClick handlers wired to the same state transition as
a mouse click — not a live-tested result.

| Screen | Title | Classification | Notes |
|---|---|---|---|
| 01 | Inventory Summary | STATIC ILLUSTRATION | Dashboard tiles computed from illustrative arrays (ITEMS/COUNTS/BATCHES). |
| 02–04 | Inventory — populated/filtered/low-stock list | DEMONSTRATED (navigation) + STATIC (data) | Row click/Enter/Space opens detail (real, guarded keyboard handler); underlying quantities are static illustrative data, not live. |
| 05 | Inventory — empty state | STATIC ILLUSTRATION | Canned empty-result layout. |
| 06 | Inventory — read-only role | STATIC ILLUSTRATION | Demonstrates permission-aware hiding of WAC via static `readOnly` flag, not a real auth check. |
| 07 | Inventory — offline/local scope | STATIC ILLUSTRATION | Banner text only; no real connectivity detection. |
| 08 | Inventory Item Detail — Overview | STATIC ILLUSTRATION | `<h1>` added this session; tab content static. |
| 09 | Inventory Item Detail — Movement History | DEMONSTRATED (navigation) + STATIC (data) | Movement rows are keyboard-activatable (guarded Enter/Space) to open drawer; ledger values are reconciled static data (F3/F4). |
| 10 | Movement Detail Drawer | STATIC ILLUSTRATION | Drawer content is static; no real `role="dialog"`/focus-trap implemented — flagged as a gap, not claimed. |
| 11 | Inventory Item Detail — Batch / Expiry | STATIC ILLUSTRATION | Batch table has ARIA role="table" semantics; data static. |
| 12 | Batch Detail | STATIC ILLUSTRATION | Static drawer-style panel. |
| 13–14 | Batch/Expiry lists (near-expiry / expired) | STATIC ILLUSTRATION | ARIA table semantics; DEC-INV-005 (FEFO/expiry policy) OPEN — no policy asserted. |
| 15 | Item Detail — read-only / permission variant | STATIC ILLUSTRATION | `<h1>` added this session. |
| 16 | Movement History — Store-wide | DEMONSTRATED (navigation) + STATIC (data) | Same guarded row-activation pattern as 09; largest single ledger table in the package. |
| 17 | Adjustment History | STATIC ILLUSTRATION | ARIA table semantics added this session. |
| 18 | New Adjustment | DEMONSTRATED (form) + STATIC (computation) | Real `<input type="number">`, `<select>`, `<textarea>`, `<label>`, `<output>` — all focusable and labelled. Typing does NOT recompute the preview or the BLOCK decision; this is explicitly a static preview, not a wired calculator. |
| 19 | Adjustment — batch tracked | STATIC ILLUSTRATION | Same form pattern as 18, extended with a static batch selector line. |
| 20 | Adjustment — validation (BLOCK computed) | STATIC ILLUSTRATION | The BLOCK/valid message is precomputed for the canned example quantity; not live. |
| 21 | Negative Stock Blocked | DESIGN INTENT + STATIC ILLUSTRATION | Demonstrates DEC-INV-010 (Phase-1 BLOCK, RESOLVED) with a worked static example; `noteBox(...,'red',true)` now correctly marked as a dynamic alert. |
| 22 | Adjustment — approval required | UNRESOLVED GAP (permission mechanism) + STATIC ILLUSTRATION | Shows an approval-pending state; no real approve/reject API or permission code exists in frozen authority — not invented here. |
| 23 | Adjustment — review | STATIC ILLUSTRATION | Canned review summary before a "Post" action that does not actually post anything. |
| 24 | Adjustment — posted | STATIC ILLUSTRATION | Posted-state confirmation screen; immutability note is DESIGN INTENT. |
| 25 | Adjustment — correction / compensating action | DESIGN INTENT | Explains the immutable-ledger correction pattern; no real second adjustment is created interactively. |
| 26 | Adjustment — safe retry / uncertain state | DESIGN INTENT | Illustrates the idempotent-retry pattern used elsewhere in approved packages; not a live retry. |
| 27–29 | Opening Stock (entry / review / posted) | STATIC ILLUSTRATION + DESIGN INTENT | DEC-INV-008 is PROPOSED, not RESOLVED — screens state this explicitly rather than asserting a frozen lifecycle. |
| 30 | Stock Counts — master list | STATIC ILLUSTRATION | Not yet converted to ARIA table semantics this session — see remaining checklist. |
| 31 | Create Stock Count | STATIC ILLUSTRATION | Form-shaped but not converted to real inputs this session. |
| 32 | Count Scope | STATIC ILLUSTRATION | Static scope summary. |
| 33 | Count Entry — standard | DEMONSTRATED (field) + STATIC (recompute) | Real `<input type="number">` per row with per-item `aria-label`; does not recompute variance live. |
| 34 | Count Entry — blind | DEMONSTRATED (field) + STATIC (recompute) | Same as 33, with expected quantity intentionally hidden (blind-count UX), per-item `aria-label` notes this. |
| 35 | Count Entry — barcode/search | DEMONSTRATED (field) + STATIC (recompute) | Shares the same real-input pattern as 33/34. |
| 36 | Count Entry — validation | STATIC ILLUSTRATION | Canned validation message, not wired to the real inputs on 33–35. |
| 37–38 | Count Review / Variance | STATIC ILLUSTRATION | `REVIEW_LINES_REF` now explicitly ties this screen's variance table to CNT-2026-00012 (F3 fix). |
| 39 | Count — approval required | UNRESOLVED GAP (permission mechanism) | Same caveat as screen 22: no real approval API/permission exists; not invented. |
| 40 | Count — posted | STATIC ILLUSTRATION | Posted confirmation. |
| 41 | Count — cancelled | UNRESOLVED GAP (cancellation mechanism) | Cancellation policy/authority not defined; screen states the cancellation occurred without asserting a cancel API. |
| 42 | Count — safe retry / uncertain | DESIGN INTENT | Same idempotent-retry pattern as screen 26. |
| 43 | Count variance — item drill-down | STATIC ILLUSTRATION | Not independently re-verified against 37/38/46/47/16/30 beyond the CNT-2026-00012 chain fixed this revision (F3 note: other cross-references not re-opened). |
| 44 | Count — concurrency conflict | DESIGN INTENT | Illustrates DEC-INV-003 (concurrency policy OPEN) without choosing lock-vs-snapshot. |
| 45 | Stock Counts — filtered list | STATIC ILLUSTRATION | Shares the master-list pattern (30), same ARIA-table gap. |
| 46 | Posted Count (read-only) | STATIC ILLUSTRATION | `REVIEW_LINES_REF` now shown explicitly (F3 fix). |
| 47 | Count — audit timeline | STATIC ILLUSTRATION | Not converted to ARIA table semantics this session. |
| 48 | Count — batch-aware entry | DEMONSTRATED (field) + STATIC (recompute) | Shares the real-input pattern where applicable. |
| 49–51 | Responsive illustrations (1280×720 list/count/adjustment) | STATIC ILLUSTRATION | These are fixed-size illustrative renders of other screens at one viewport; NOT a substitute for live four-viewport verification, which remains unperformed (Claude Code to run). |
| 52–54 | DataTable / Quantity-status / Movement component galleries | DESIGN INTENT | Component reference sheets, not product screens. |
| 55 | Batch / Expiry components | DESIGN INTENT | Same as above. |
| 56–58 | Adjustment / Count / Permission component galleries | DESIGN INTENT | Same as above. |
| 59 | Offline / Error states gallery | DESIGN INTENT | Static state-card gallery. |
| 60 | Inventory component inventory + documentation | DESIGN INTENT | Prose documentation; `<h1>` added this session. |
| 61 | Reorder / Low Stock — decision support | DESIGN INTENT + UNRESOLVED GAP | Explicitly states DEC-INV-007 (threshold ownership) is OPEN; illustrative threshold column labelled as an example, not a configured value. |
| 62 | Inventory — LOADING state | STATIC ILLUSTRATION | `role="status"`/`aria-live="polite"` skeleton. |
| 63 | Inventory — EMPTY state | STATIC ILLUSTRATION | Canned empty-result card with a "Clear filters" action that is not wired to real filter state. |
| 64 | Inventory — CONFLICT (stale version) state | STATIC ILLUSTRATION | `role="alert"` card; no real version/ETag check exists. |
| 65 | Inventory — INCOMPATIBLE_CLIENT state | STATIC ILLUSTRATION | `role="alert"` card; no real client-version check exists. |
| 66 | Inventory — VALIDATION_ERROR (field-level) state | DEMONSTRATED (field) + STATIC (error) | Real `<input aria-invalid="true" aria-describedby>` with a real associated `role="alert"` error message — added this session. Does not submit to a real backend. |
| 67 | Inventory — PERMISSION_DENIED (posting) state | STATIC ILLUSTRATION | `noteBox(...,'amber',true)` — a real dynamic-style alert describing a role-based posting restriction; no real permission code is asserted (per instruction, none invented). |

## Summary counts
DEMONSTRATED (real focusable/labelled controls): screens 02–04, 09, 16, 18, 19, 33,
34, 35, 48, 66 (10 screens, some shared with STATIC data below them).
STATIC ILLUSTRATION: the majority of the remaining content screens (exact mix noted
per row above — most DEMONSTRATED rows also carry a STATIC data/recompute caveat).
DESIGN INTENT (annotations/galleries/boundary notes): 21, 25, 26, 42, 44, 52–61 inclusive except 61's gap note, 67's permission note.
UNRESOLVED GAP (no frozen mechanism, explicitly not invented): 22, 39, 41, 61.

This traceability file reflects source-level inspection of the final packaged
MiniMartInventory.dc.html only. It has not been cross-checked against the frozen
FR-INV/UI-INV numbered requirements documents line-by-line in this pass (that full
FRS-to-screen audit remains a separate, larger undertaking — see the remaining-work
checklist in the export manifest).
