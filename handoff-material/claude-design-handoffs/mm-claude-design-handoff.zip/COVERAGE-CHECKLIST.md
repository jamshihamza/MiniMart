# Coverage checklist (what the Claude Design export must contain)

Use this to review the export. It restates the frozen requirements; the frozen documents win on any difference.

## Requirements
- [ ] Every FR-RPT-001..065 maps to at least one screen (FR-RPT-063 and 065 may map to a decisions/documentation screen).
- [ ] Frozen screens UI-RPT-001..005 and the export path are each recognisable, with their APIs (API-RPT-001/002/003) and permissions (`reporting.read`, `reporting.write`) shown correctly.

## Report families
- [ ] Sales (FR-RPT-016..026), Cash and day close (027..030, flagged as no frozen owner screen), Inventory (031..038), Purchasing (039..042), Credit and collections (043..046), Management (047..049, flagged), Central / multi-branch (054, 055, flagged Phase 3).

## States
- [ ] LOADING, READY, EMPTY, VALIDATION_ERROR, PERMISSION_DENIED, CONFLICT, LOCAL_CLOUD_OFFLINE, STORE_NODE_UNREACHABLE, INCOMPATIBLE_CLIENT.
- [ ] Report failure with no partial total (FR-RPT-062).
- [ ] Export: dialog, permission denied, QUEUED, RUNNING, COMPLETED hand-off, FAILED, CANCELLED, outcome unknown (Check status, Retry safely), PII notice, print preview, audit notice.

## Filters and context
- [ ] Store scope, business date, timestamp (kept distinct), counter, cashier, product, category/brand, supplier, customer, tender, status.
- [ ] Every report shows store scope, period or as-of, generated time, data basis and currency.
- [ ] Pagination with cursor and bounded pages; totals row states its scope.
- [ ] Grouping basis (historical or current master) labelled.

## Unresolved items
- [ ] Every entry in `DECISIONS-AND-GAPS.md` is visible and unresolved, with a marker and ID on the screens that depend on it.
- [ ] No invented formula, threshold, bucket, permission code, export format, retention period, report code or keyboard shortcut.
- [ ] ILLUSTRATIVE DATA notice on every content screen; design annotations visibly distinct.

## Money and country
- [ ] Decimal-string money, RM two decimals, right-aligned, tabular numerals; no tax label.
- [ ] Frozen formulas (expected cash, variance, customer outstanding/statement, WAC valuation) reconcile in the examples.

## Responsive and accessibility
- [ ] Usable at 1280x720, 1366x768, 1368x800, 1920x1080; no page-level horizontal scroll; no clipped money columns.
- [ ] Labelled controls, semantic tables, visible focus, dialog focus trap and restore, status not colour-only, contrast at least 4.5:1.

## Package format
- [ ] `MiniMartReports.dc.html` + real `support.js`; contiguous screen IDs; unique titles and states; grouped pages import the source; index page.
- [ ] `REPORTING-EXPORT-MANIFEST.txt` with SHA-256 for every file and honest statement of what was not verified.
- [ ] Dependencies only from Google Fonts and unpkg; no local paths.
