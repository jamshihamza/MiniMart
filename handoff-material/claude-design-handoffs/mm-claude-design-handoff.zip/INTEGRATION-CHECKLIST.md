# What Claude Code will do when you provide the Claude Design export

Nothing below has been started. It happens only after you provide the export.

1. Verify the actual ZIP bytes outside the repository: file count, every declared hash, undeclared and missing files.
2. Check the source: screen count and IDs, unique titles and states, JS parse, every screen instantiates, grouped pages import rather than duplicate, index is a links page.
3. Provenance: record it as a Claude Design export (archive name, manifest, source SHA-256, `support.js` SHA-256). The `D:/mm-rpt` candidate stays labelled Claude Code-authored and unapproved.
4. Compare coverage with `COVERAGE-CHECKLIST.md` and `traceability.json`: every FR-RPT, every state, every open decision still open, no invented rule or permission.
5. Register under `docs/design/reports/` in an isolated worktree based on the verified checkpoint, with status `review-ready`.
6. Run the repository gates: `pnpm design:validate`, `pnpm test:design-render`, real-runtime `pnpm design:render --package reports`, `pnpm design:report`, `pnpm run ci`, `git diff --check`, plus frozen-diff checks.
7. Render all screens at 1280x720, 1366x768, 1368x800 and 1920x1080 and scan for page scroll and clipping, then inspect key screens by eye.
8. Audit accessibility structure and contrast.
9. Report fidelity gaps honestly. Status stays `review-ready` until you approve visually.

No frozen change, implementation, commit or push is part of this.
