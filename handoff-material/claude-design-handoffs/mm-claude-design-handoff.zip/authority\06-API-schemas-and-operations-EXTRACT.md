# Verbatim extract: report API schemas and operations

Extracted unchanged from the frozen API contract. The frozen files are authoritative; this extract only saves you from opening a 30,000-line OpenAPI file.

## Operations (registry/operations-v1.0.json)

```json
{
  "id": "API-IMP-005",
  "method": "GET",
  "path": "/api/v1/exports/{exportJobId}",
  "module": "Import / Export",
  "kind": "QUERY",
  "summary": "Get export job/status",
  "fr": "FR-IMP-001..045",
  "request": null,
  "response": "ExportJob",
  "idempotency_required": false,
  "if_match_required": false,
  "security": "session",
  "decision_seams": [],
  "statuses": [
    "200"
  ],
  "coordinator": null,
  "notes": "",
  "permission_code": "import.read",
  "error_codes": [
    "AUTHENTICATION_REQUIRED",
    "INCOMPATIBLE_CLIENT",
    "PERMISSION_DENIED",
    "RESOURCE_NOT_FOUND",
    "SERVICE_UNAVAILABLE",
    "VALIDATION_FAILED"
  ],
  "guard_codes": []
}
```

```json
{
  "id": "API-IMP-010",
  "method": "GET",
  "path": "/api/v1/exports/{exportJobId}/artifact",
  "module": "Import / Export",
  "kind": "QUERY",
  "summary": "Get export artifact descriptor/download handle",
  "fr": "FR-IMP-035..044",
  "request": null,
  "response": "ExportArtifact",
  "idempotency_required": false,
  "if_match_required": false,
  "coordinator": null,
  "security": "session",
  "decision_seams": [],
  "statuses": [
    "200"
  ],
  "permission_code": "export.read",
  "error_codes": [
    "AUTHENTICATION_REQUIRED",
    "INCOMPATIBLE_CLIENT",
    "PERMISSION_DENIED",
    "RESOURCE_NOT_FOUND",
    "SERVICE_UNAVAILABLE",
    "VALIDATION_FAILED"
  ],
  "notes": "",
  "guard_codes": []
}
```

```json
{
  "id": "API-RPT-001",
  "method": "GET",
  "path": "/api/v1/reports/definitions",
  "module": "Reporting",
  "kind": "QUERY",
  "summary": "List report definitions and supported filters/grouping modes",
  "fr": "FR-RPT-001..065",
  "request": null,
  "response": "ReportDefinitionPage",
  "idempotency_required": false,
  "if_match_required": false,
  "security": "session",
  "decision_seams": [
    "DEC-RPT-001",
    "DEC-RPT-002"
  ],
  "statuses": [
    "200"
  ],
  "coordinator": null,
  "notes": "",
  "permission_code": "reporting.read",
  "error_codes": [
    "AUTHENTICATION_REQUIRED",
    "INCOMPATIBLE_CLIENT",
    "PERMISSION_DENIED",
    "RESOURCE_NOT_FOUND",
    "SERVICE_UNAVAILABLE",
    "VALIDATION_FAILED"
  ],
  "guard_codes": []
}
```

```json
{
  "id": "API-RPT-002",
  "method": "POST",
  "path": "/api/v1/reports/{reportCode}:run",
  "module": "Reporting",
  "kind": "QUERY",
  "summary": "Run bounded report query",
  "fr": "FR-RPT-001..065",
  "request": "ReportRunRequest",
  "response": "ReportResult",
  "idempotency_required": false,
  "if_match_required": false,
  "security": "session",
  "decision_seams": [
    "DEC-RPT-001",
    "DEC-RPT-002"
  ],
  "statuses": [
    "200"
  ],
  "coordinator": null,
  "notes": "",
  "permission_code": "reporting.read",
  "error_codes": [
    "AUTHENTICATION_REQUIRED",
    "INCOMPATIBLE_CLIENT",
    "PERMISSION_DENIED",
    "RESOURCE_NOT_FOUND",
    "SERVICE_UNAVAILABLE",
    "VALIDATION_FAILED"
  ],
  "guard_codes": []
}
```

```json
{
  "id": "API-RPT-003",
  "method": "POST",
  "path": "/api/v1/reports/{reportCode}:export",
  "module": "Reporting",
  "kind": "COMMAND",
  "summary": "Create report export job",
  "fr": "FR-RPT-001..065,FR-IMP-001..045",
  "request": "ReportExportRequest",
  "response": "ExportJob",
  "idempotency_required": true,
  "if_match_required": false,
  "security": "session",
  "decision_seams": [
    "DEC-RPT-001",
    "DEC-RPT-002"
  ],
  "statuses": [
    "200"
  ],
  "coordinator": null,
  "notes": "",
  "permission_code": "reporting.write",
  "error_codes": [
    "AUTHENTICATION_REQUIRED",
    "BUSINESS_RULE_REJECTED",
    "IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST",
    "INCOMPATIBLE_CLIENT",
    "PERMISSION_DENIED",
    "RESOURCE_NOT_FOUND",
    "SERVICE_UNAVAILABLE",
    "VALIDATION_FAILED"
  ],
  "guard_codes": []
}
```

## Schemas

### ReportDefinitionPage

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 28950

```yaml
    ReportDefinitionPage:
      type: object
      additionalProperties: false
      required:
      - items
      - page
      properties:
        items:
          type: array
          items:
            $ref: '#/components/schemas/ReportDefinition'
        page:
          $ref: '#/components/schemas/PageInfo'
```

### ReportDefinition

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 28513

```yaml
    ReportDefinition:
      type: object
      additionalProperties: false
      required:
      - code
      - nameKey
      - supportedFilters
      - supportedGroupingModes
      properties:
        code:
          type: string
        nameKey:
          type: string
        supportedFilters:
          type: array
          items:
            type: string
        supportedGroupingModes:
          type: array
          items:
            type: string
```

### ReportRunRequest

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 28152

```yaml
    ReportRunRequest:
      type: object
      additionalProperties: false
      required: []
      properties:
        filters:
          type: array
          items:
            type: object
            additionalProperties: false
            required:
            - field
            - operator
            - value
            properties:
              field:
                type: string
              operator:
                type: string
              value:
                type: string
        groupingMode:
          anyOf:
          - type: string
          - type: 'null'
        cursor:
          anyOf:
          - type: string
          - type: 'null'
        limit:
          type: integer
          minimum: 1
          maximum: 500
```

### ReportResult

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 26773

```yaml
    ReportResult:
      type: object
      additionalProperties: false
      required:
      - columns
      - rows
      properties:
        columns:
          type: array
          items:
            $ref: '#/components/schemas/ReportColumn'
        rows:
          type: array
          items:
            $ref: '#/components/schemas/ReportRow'
        nextCursor:
          anyOf:
          - type: string
          - type: 'null'
```

### ReportColumn

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 26741

```yaml
    ReportColumn:
      type: object
      additionalProperties: false
      required:
      - key
      - labelKey
      - type
      properties:
        key:
          type: string
        labelKey:
          type: string
        type:
          type: string
          enum:
          - STRING
          - DECIMAL
          - MONEY
          - DATE
          - DATETIME
          - INTEGER
          - BOOLEAN
```

### ReportRow

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 26763

```yaml
    ReportRow:
      type: object
      additionalProperties: false
      required:
      - cells
      properties:
        cells:
          type: array
          items:
            type: string
```

### PageInfo

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 24500

```yaml
    PageInfo:
      type: object
      additionalProperties: false
      required:
      - hasMore
      - limit
      properties:
        nextCursor:
          anyOf:
          - type: string
          - type: 'null'
        hasMore:
          type: boolean
        limit:
          type: integer
          minimum: 1
          maximum: 200
```

### ReportExportRequest

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 28185

```yaml
    ReportExportRequest:
      type: object
      additionalProperties: false
      required:
      - format
      properties:
        format:
          type: string
          enum:
          - CSV
          - XLSX
        filters:
          type: array
          items:
            type: string
```

### ExportJob

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 26614

```yaml
    ExportJob:
      type: object
      additionalProperties: false
      required:
      - id
      - status
      - format
      properties:
        id:
          $ref: '#/components/schemas/Uuid'
        status:
          type: string
          enum:
          - QUEUED
          - RUNNING
          - COMPLETED
          - FAILED
          - CANCELLED
        format:
          type: string
          enum:
          - CSV
          - XLSX
        artifactId:
          anyOf:
          - $ref: '#/components/schemas/Uuid'
          - type: 'null'
```

### ExportArtifact

Source: docs/specifications/05-api-contracts/openapi/minimart-store-node-v1.yaml line 26641

```yaml
    ExportArtifact:
      type: object
      additionalProperties: false
      required:
      - artifactId
      - fileName
      - mediaType
      - sizeBytes
      - sha256
      - expiresAt
      - contentPath
      properties:
        artifactId:
          $ref: '#/components/schemas/Uuid'
        mediaType:
          type: string
        fileName:
          type: string
        sha256:
          type: string
        sizeBytes:
          type: integer
          minimum: 0
        expiresAt:
          anyOf:
          - *id003
          - type: 'null'
        contentPath:
          type: string
          pattern: ^/api/v1/artifacts/[0-9A-Fa-f-]+/content$
```

