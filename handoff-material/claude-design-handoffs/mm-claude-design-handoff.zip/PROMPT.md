# Claude Design prompt: MiniMart Reporting visual mockups

Paste everything below the line into Claude Design, and attach the files listed in `ATTACHMENTS.md`.

---

You are designing the **Reporting** module visual mockups for **MiniMart**, an offline-first retail POS and back-office platform (Malaysia first, currency MYR). Produce a reviewable Claude Design package in the same format and visual system as the previously approved MiniMart packages.

## 0. Ground rules

1. The attached **frozen requirements, UI contracts and API contracts are authoritative**. Design never overrides them. If a screen would need a rule that the frozen documents do not state, **do not invent it**: show the slot as an explicitly qualified example or an unresolved placeholder, using the markers in section 5.
2. `approved-references/accounting/` is an **approved visual reference**. Match its shell, tokens, typography, spacing, table and card styling, status chips, note boxes and state patterns. `approved-references/design-system-base/MiniMartBackOffice.dc.html` is the Back Office source it descends from. It is **review-ready, not approved**: use it only as a design-system base.
3. `candidate-INPUT-ONLY/` is a rough candidate written by a coding agent, **not** by Claude Design and **not approved**. Use it as input only: a coverage checklist and a source of useful states. Improve on it. Do not copy its mistakes or treat its look as authoritative.
4. Reporting is a **read-only** consumer of posted data. No screen may edit, delete, repost or reverse a source record.
5. Reports are **operational**, not statutory accounting. Do not introduce a Chart of Accounts, journal, trial balance, balance sheet, statutory P&L or period close, except as an out-of-scope disclaimer.

## 1. What to design

Cover **every** requirement FR-RPT-001 to FR-RPT-065 (`authority/01-FRS-reporting-FR-RPT-001-065.md`), organised around the frozen screens UI-RPT-001 to UI-RPT-005 and the export path. See `candidate-INPUT-ONLY/CANDIDATE-SCREEN-LIST.md` for the candidate's coverage (80 screens) and `candidate-INPUT-ONLY/traceability.json`.

Frozen screens and APIs:

| Frozen screen | Purpose | APIs | Permissions |
| --- | --- | --- | --- |
| UI-RPT-001 Reports Home | Authorized report catalog | API-RPT-001/002/003 | `reporting.read`, `reporting.write` |
| UI-RPT-002 Sales Report | Sales/tender/date/store views | same | same |
| UI-RPT-003 Inventory Report | Stock/movement/low-stock | same | same |
| UI-RPT-004 Purchase / Supplier Report | Purchasing/payables reporting | same | same |
| UI-RPT-005 Credit / Collection Report | Customer credit and collections | same | same |
| UI-EXP-001 Export Center | Create/download export artifacts (Import/Export owns the artifact) | API-IMP-001..006 | `import.read`, `import.write` |

API facts (see `authority/06-API-schemas-and-operations-EXTRACT.md`): API-RPT-001 lists report definitions with `code`, `nameKey`, `supportedFilters`, `supportedGroupingModes`. API-RPT-002 runs a bounded report and returns `columns` (`key`, `labelKey`, `type` in STRING/DECIMAL/MONEY/DATE/DATETIME/INTEGER/BOOLEAN), `rows` (`cells` as strings, money as decimal strings) and `nextCursor`. API-RPT-003 creates an export job (`format` CSV or XLSX; needs `reporting.write`; idempotent). `ExportJob.status` is QUEUED, RUNNING, COMPLETED, FAILED or CANCELLED. Report codes, name keys, filter field codes and operators are **not frozen**.

Report families to design (names come from the FRS; report codes are not frozen):

- **Sales** (FR-RPT-016..026): daily sales summary, by item, by category, by cashier, by counter, discounts, price overrides, returns, no-receipt returns (only if enabled), tender summary, payment exceptions.
- **Cash and day close** (FR-RPT-027..030): cash movement, cash variance, shift close, day close. No frozen owner screen exists. Mark this as an authority gap.
- **Inventory** (FR-RPT-031..038): current stock, low stock, negative stock, stock movement, batch/expiry, valuation, count variance, adjustments.
- **Purchasing** (FR-RPT-039..042): purchase summary, by supplier, purchase returns, price history.
- **Credit and collections** (FR-RPT-043..046): customer outstanding, aging, statement, credit overrides.
- **Management** (FR-RPT-047..049): daily summary, exception highlights, optional comparative periods. No frozen owner screen exists (UI-SYS-003 is the nearest role dashboard). Mark this as an authority gap.
- **Cross-cutting** (FR-RPT-001..015, 050..065): read-only principle, authorization, store scope, business date versus timestamp, filters, generated timestamp and scope, pagination, totals definitions, historical versus current grouping, as-of, local/offline scope, central multi-branch and incomplete-sync warning (Phase 3, later), print, export, export permission, PII-aware export, audit, failure behaviour, no accounting claim.

## 2. States and recovery that must be shown

From `authority/07-UI-screen-state-contract.md` and `08-UI-command-and-recovery-contract.md`: LOADING, READY, EMPTY, VALIDATION_ERROR, PERMISSION_DENIED, CONFLICT, LOCAL_CLOUD_OFFLINE (local reports continue and say so), STORE_NODE_UNREACHABLE (reports blocked; distinct from cloud-offline), INCOMPATIBLE_CLIENT, and RECOVERY_REQUIRED where a command is involved.

Also: report failure shows a status and **never a partial total** (FR-RPT-062); an empty result is not an error; unresolved payment states (pending, uncertain, failed) are never counted as confirmed (FR-RPT-013, 026).

**Export states** (API-RPT-003, ExportJob): export dialog (format, scope echo), permission denied (needs `reporting.write`, separate from viewing), QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED, outcome unknown (lost response: **Check status** and **Retry safely** with the same idempotency identity; never create a duplicate job), PII-minimised export notice, print preview, and the audit notice. Artifact download, retention and delivery belong to **Export Center / Import-Export**, so Reporting hands off with a "Continue in Export Center" action. Do not design an artifact lifecycle, export queue, retention policy or file-format policy inside Reporting.

## 3. Responsive and accessibility requirements

- Desktop-first, Back Office target 1366x768 and above, minimum validation 1280x720. Design and check at **1280x720, 1366x768, 1368x800 and 1920x1080**. No page-level horizontal scrolling at any of them. Primary actions and totals stay reachable. Tables must not clip monetary or accountable columns.
- Visible focus on every actionable element; logical tab order; dialogs trap and restore focus; names for icon-only controls; errors identify the field and the fix; status is never colour alone; text zoom and Windows display scaling must not hide primary actions; respect reduced motion (UI spec 07 and 24).
- Use real labelled form controls and semantic tables with captions and column headers. **No keyboard shortcut is defined for Back Office reports; do not invent one.** Every action has a visible control.
- Text contrast at least 4.5:1. The candidate found that two approved-package tones fall just below that on tinted surfaces (muted text `#6b7585` on `#f7f9fb` and `#f2f4f7`, and sidebar group labels `#6f7c93` on `#0e1b33`). Keep the approved look but correct those pairs, and say so in your manifest.

## 4. Money, quantity and country context

Money is a decimal string end to end. Show `RM` with two decimals, right-aligned, tabular numerals, a minus sign for negatives, in a MYR / Malaysia context. Never imply binary floating point. Show tax labels **only** if a verified country capability exists, so show none. Quantity follows each item's UoM precision. Rounding comes from country rules, not from the design. Show business date and timestamp as separate concepts. State store scope, period or as-of, and generated time on every report.

## 5. Illustrative data and unresolved items (must be visible)

- Every screen carries a persistent **ILLUSTRATIVE DATA** notice. All numbers are examples. Do not present any example as a live figure or as an approved calculation.
- Where a formula or definition is frozen, you may compute with it and cite it: expected cash and variance (`authority/16-DOMAIN-credit-cash-accounting.md`), customer outstanding and statement closing balance (domain doc and AC-B4-020), inventory valuation as moving weighted-average cost (DEC-INV-001).
- Where it is not frozen, **do not assert a formula**: gross/net/discount/return/tax definitions (FR-RPT-016, 050), aging buckets (FR-RPT-044), low-stock thresholds (DEC-INV-007), expiry windows (DEC-INV-005), grouping basis historical versus current master (DEC-RPT-001), approved comparison periods (FR-RPT-049), print channel and page size, report access audit policy, artifact retention, report codes and filter field codes.
- Use visible chips on every dependent screen: `OPEN`, `VERIFY`, `PROPOSED`, `DEFERRED`, `RESOLVED`, `GAP`, `LATER` with the ID. Show design annotations in a clearly different dashed "not product UI" style.
- Keep **every** item in `DECISIONS-AND-GAPS.md` explicit. Do not resolve any of them. If a screen depends on one, mark the dependency and design the independent parts fully.
- Permissions beyond `reporting.read` and `reporting.write` are not defined (cost-sensitive access, source drill-down, unmasking customer data, sensitive export, per-cashier visibility). Show these as `GAP`, not as invented permission codes.
- Cross-module consistency: reuse the approved packages' illustrative anchors where natural (store MiniMart Central, business date Sat 26 Sep 2026, GRN-2026-00374/381/392, suppliers Kluang Dairy, Segamat Poultry, Johor Beverage, customer outstanding RM 2,145.00). Customer names are masked by default.

## 6. Deliverable format (must match prior Claude Design exports)

- A Claude Design **`.dc.html` source** for the whole module, named `MiniMartReports.dc.html`, using `<x-dc>`, `<helmet>`, the inline `data-dc-script` component and a `screen` enum prop with contiguous IDs `01` to `NN`, a `$preview` of 1366x768, an `embedded` prop, and `data-screen-label="NN <title>"` on the root. Include the real `support.js` unchanged (copy from the attached Accounting package).
- Unique titles and unique state mappings for every screen. Every screen must instantiate.
- Grouped canvas pages (like the Accounting package) that import the authoritative source, so no screen logic is duplicated, plus an index page listing them. Cover every screen exactly once. Do not include a Back Office source copy in the archive.
- An export manifest `REPORTING-EXPORT-MANIFEST.txt` listing every packaged file with a SHA-256 computed from the final bytes, the screen count, the grouping, and an explicit statement of what you could not verify. State honestly whether you rendered the four viewports live.
- External dependencies only from Google Fonts and `unpkg.com` (IBM Plex Sans/Mono, `lucide-static@0.469.0`). No other hosts, no local absolute paths.
- Archive name: `MiniMart_Reporting_ClaudeDesign_Source.zip`.

## 7. Process

1. Read the attachments in the order given in `ATTACHMENTS.md`. Frozen files first.
2. State any **authority conflict** you find (two frozen statements that disagree) instead of resolving it. The page-limit mismatch is already known: `ReportRunRequest.limit` allows 1 to 500, but `PageInfo.limit` allows at most 200.
3. Design independent screens first. For a screen that depends on an open decision, mark the dependency and keep going.
4. Finish with a checklist of requirement IDs to screen numbers.
5. Do **not** label anything "approved". The package status is review-ready until the owner approves it visually.
