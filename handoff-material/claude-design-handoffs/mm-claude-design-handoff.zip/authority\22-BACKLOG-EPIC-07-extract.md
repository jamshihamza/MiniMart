# Backlog EPIC-07 (verbatim from docs/backlog/docs/04-BACKLOG-CATALOG.md)

Reporting items are MM-079..MM-083; Export Center is MM-097.

## EPIC-07 --- Phase 2 --- Reports, Import/Export & Operations

Reports, import/export, backup, diagnostics and audit tooling.

-   **MM-079 \[P1\]** Implement Reports Home --- UI UI-RPT-001; 3 API
    ops
-   **MM-080 \[P1\]** Implement Sales Report --- UI UI-RPT-002; 3 API
    ops
-   **MM-081 \[P1\]** Implement Inventory Report --- UI UI-RPT-003; 3
    API ops
-   **MM-082 \[P1\]** Implement Purchase / Supplier Report --- UI
    UI-RPT-004; 3 API ops
-   **MM-083 \[P1\]** Implement Credit / Collection Report --- UI
    UI-RPT-005; 3 API ops
-   **MM-084 \[P1\]** Implement Audit Explorer --- UI UI-AUD-001; 2 API
    ops
-   **MM-088 \[P1\]** Implement Company Settings --- UI UI-ORG-001; 6
    API ops
-   **MM-089 \[P1\]** Implement Stores --- UI UI-ORG-002; 8 API ops
-   **MM-090 \[P1\]** Implement Counters --- UI UI-ORG-003; 12 API ops
-   **MM-093 \[P1\]** Implement Hardware Setup --- UI UI-HW-001; 2 API
    ops
-   **MM-094 \[P1\]** Implement Backup & Restore Center --- UI
    UI-BAK-001; 3 API ops
-   **MM-095 \[P1\]** Implement Support & Diagnostics --- UI
    UI-SUPT-001; 3 API ops
-   **MM-096 \[P1\]** Implement Import Center --- UI UI-IMP-001; 13 API
    ops
-   **MM-097 \[P1\]** Implement Export Center --- UI UI-EXP-001; 6 API
    ops

