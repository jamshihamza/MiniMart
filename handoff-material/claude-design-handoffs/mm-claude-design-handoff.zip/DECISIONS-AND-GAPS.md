# Unresolved decisions and authority gaps (to qualify visibly in the mockups)

Synthesised from the frozen documents by the Claude Code candidate. Each ID should be checked against `authority/18-DECISION-REGISTER.md` and `authority/17-DOMAIN-decision-seam-matrix.md`. This list does not resolve anything. Do not choose a value for any item below; show it as an explicitly qualified example or leave the slot visibly unresolved.

## Decisions (Decision Register / seam matrix)

| ID | Status | What is undecided | Affects |
| --- | --- | --- | --- |
| DEC-RPT-001 | OPEN | Historical versus current master grouping, decided per report. | Sales by Category; grouping screens |
| DEC-RPT-002 | PROPOSED | The Phase-2 baseline report list is the one in the Reporting FRS. The design follows that list; it is not frozen. | Reports Home |
| FR-RPT-050 / 016 | OPEN | Definitions of gross sales, discounts, returns, net sales and tax for reports. FR-RPT-016 requires "approved" definitions that no document states. | Every sales report; definitions screen |
| FR-RPT-044 | OPEN | Approved aging buckets and the due-date basis (with DEC-CRD-002). | Customer Aging Report |
| DEC-INV-007 | OPEN | Who owns the reorder or low-stock threshold. | Low Stock Report |
| DEC-INV-004 / 005 | OPEN | Batch selection and expiry/FEFO policy; DEC-POS-003 expiry-sale policy is VERIFY. | Batch / Expiry Report |
| DEC-INV-003 | OPEN | Stock-count concurrency policy. | Stock Count Variance Report |
| DEC-RET-001 | OPEN | Whether no-receipt returns exist and under what eligibility. | No-Receipt Return Report |
| DEC-CRD-001 / 002 / 003 / 004 | OPEN | Credit limit, collection allocation, customer advance and suspended-credit override policies. | Credit reports |
| DEC-CSH-001..005, DEC-COM-001 | OPEN | Business-date rollover, day close, late transactions, reopen and active-shift policies. | Cash and day close reports; date filters |
| DEC-PAY-001 | PROPOSED | Card and QR adapter baseline behaviour. | Tender and Payment Exception reports |
| DEC-CUS-002 | VERIFY | Customer retention and anonymisation period. | Customer data screens |
| DEC-PUR-001 / 002 / 006 | PROPOSED | Purchase-order and direct-GRN policy. Tax recoverability is VERIFY. | Purchasing reports |
| DEC-INV-001 | RESOLVED | Moving weighted-average cost per Item per Store. Used for inventory valuation. | Inventory Valuation Report |
| DEC-INV-010 | RESOLVED | Phase-1 negative-stock default is BLOCK. | Negative Stock Report |

## Authority gaps (no decision ID)

| Gap | Detail |
| --- | --- |
| Report codes, name keys, filter field codes and operators are not frozen | ReportDefinition and ReportRunRequest define only the shapes. The design uses human labels. |
| No frozen screen owns Cash/Shift/Day-close reports or the Management Daily Summary | UI-RPT-001..005 cover sales/tender, inventory, purchasing/payables and credit/collections. The cash and management reports in FR-RPT-027..030 and 047..049 have no named screen. |
| Permissions beyond reporting.read and reporting.write are not defined | Needed for cost-sensitive access, source drill-down, unmasking customer data, sensitive export and per-cashier visibility. |
| Hand-off from a report to Export Center is not described | UI-EXP-001 lists import and export operations only. The "Continue in Export Center" link is a design proposal. |
| Page limits differ between contracts | ReportRunRequest.limit allows 1–500 while PageInfo.limit allows at most 200. |
| No central or multi-branch report screen exists (Phase 3) | UI-CLD-001..003 are cloud screens; FR-RPT-054/055 have no frozen screen. |
| Print channel, page size and orientation are undefined | FR-RPT-056 says "readable form" only. |
| Audit policy for report access and export is undefined | FR-RPT-061 is a SHOULD "according to policy". |
| Export artifact retention is a policy seam | API 16-IMPORT-EXPORT-JOB-ARTIFACT. |
| Performance targets and the acceptance suite are not visual | FR-RPT-063 and FR-RPT-065 need data volumes and tests, not screens. |
