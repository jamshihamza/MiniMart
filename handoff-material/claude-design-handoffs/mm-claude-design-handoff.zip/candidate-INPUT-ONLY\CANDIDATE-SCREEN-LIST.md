# Candidate screen and state coverage (INPUT ONLY, not approved)

The current Claude Code candidate has 80 screens. Use it as a coverage checklist and as a source of useful states. You may reorganise, rename and improve. Every requirement ID below must still be represented.

| # | Screen | Group | Requirements |
| --- | --- | --- | --- |
| 01 | Reports Home — authorized catalog | Reports Home | FR-RPT-001, FR-RPT-002, FR-RPT-014, FR-RPT-047, FR-RPT-048 |
| 02 | Reports Home — search and family filter applied | Reports Home | FR-RPT-002 |
| 03 | Report definition — supported filters and grouping | Reports Home | FR-RPT-001, FR-RPT-009, FR-RPT-051 |
| 04 | Reports Home — loading | Reports Home | FR-RPT-015 |
| 05 | Reports Home — empty (no authorized reports) | Reports Home | FR-RPT-002 |
| 06 | Reports Home — permission denied | Reports Home | FR-RPT-002 |
| 07 | Reports Home — local scope (cloud sync unavailable) | Reports Home | FR-RPT-053 |
| 08 | Reports Home — Store Node unavailable | Reports Home | FR-RPT-062 |
| 09 | Reports Home — incompatible client | Reports Home | FR-RPT-062 |
| 10 | Reports Home — later-phase central reports | Reports Home | FR-RPT-054, FR-RPT-055 |
| 11 | Report viewer — anatomy | Report viewer | FR-RPT-001, FR-RPT-003, FR-RPT-014, FR-RPT-015, FR-RPT-050, FR-RPT-053, FR-RPT-056, FR-RPT-057 |
| 12 | Filter bar — filters and applicability | Report viewer | FR-RPT-003, FR-RPT-004, FR-RPT-005, FR-RPT-006, FR-RPT-007, FR-RPT-008, FR-RPT-009, FR-RPT-010, FR-RPT-011, FR-RPT-012, FR-RPT-013 |
| 13 | Business date versus timestamp | Report viewer | FR-RPT-004, FR-RPT-005 |
| 14 | Totals definitions — status of each term | Report viewer | FR-RPT-050, FR-RPT-016, FR-RPT-036, FR-RPT-044 |
| 15 | Grouping basis — historical or current master | Report viewer | FR-RPT-009, FR-RPT-051 |
| 16 | As-of reporting | Report viewer | FR-RPT-052 |
| 17 | Pagination and bounded results | Report viewer | FR-RPT-015 |
| 18 | Drill-down — source reference (read-only) | Report viewer | FR-RPT-017, FR-RPT-001 |
| 19 | Report — loading | Report states | FR-RPT-015 |
| 20 | Report — empty result | Report states | FR-RPT-013 |
| 21 | Report — validation error | Report states | FR-RPT-004 |
| 22 | Report — permission denied | Report states | FR-RPT-002 |
| 23 | Report — definition conflict | Report states | FR-RPT-062 |
| 24 | Report — run failed (no partial totals) | Report states | FR-RPT-062 |
| 25 | Report — local scope (cloud sync unavailable) | Report states | FR-RPT-053 |
| 26 | Report — Store Node unavailable | Report states | FR-RPT-062 |
| 27 | Report — incompatible client | Report states | FR-RPT-062 |
| 28 | Read-only guarantee and operational scope | Report states | FR-RPT-001, FR-RPT-064 |
| 29 | Daily Sales Summary | Sales reports | FR-RPT-016, FR-RPT-004, FR-RPT-050 |
| 30 | Sales by Item | Sales reports | FR-RPT-017, FR-RPT-008 |
| 31 | Sales by Category | Sales reports | FR-RPT-018, FR-RPT-009, FR-RPT-051 |
| 32 | Sales by Cashier | Sales reports | FR-RPT-019, FR-RPT-007 |
| 33 | Sales by Counter | Sales reports | FR-RPT-020, FR-RPT-006 |
| 34 | Discount Report | Sales reports | FR-RPT-021, FR-RPT-007 |
| 35 | Price Override Report | Sales reports | FR-RPT-022 |
| 36 | Returns Report | Sales reports | FR-RPT-023 |
| 37 | No-Receipt Return Report | Sales reports | FR-RPT-024 |
| 38 | Tender Summary | Sales reports | FR-RPT-025, FR-RPT-012, FR-RPT-013 |
| 39 | Payment Exception Report | Sales reports | FR-RPT-026, FR-RPT-013 |
| 40 | Cash Movement Report | Cash and day close reports | FR-RPT-027, FR-RPT-006, FR-RPT-007 |
| 41 | Cash Variance Report | Cash and day close reports | FR-RPT-028, FR-RPT-006, FR-RPT-007 |
| 42 | Shift Close Report | Cash and day close reports | FR-RPT-029 |
| 43 | Day Close Report | Cash and day close reports | FR-RPT-030 |
| 44 | Current Stock | Inventory reports | FR-RPT-031, FR-RPT-008 |
| 45 | Low Stock Report — threshold ownership undefined | Inventory reports | FR-RPT-032 |
| 46 | Negative Stock Report — normally empty | Inventory reports | FR-RPT-033 |
| 47 | Stock Movement Report | Inventory reports | FR-RPT-034, FR-RPT-008 |
| 48 | Batch / Expiry Report | Inventory reports | FR-RPT-035 |
| 49 | Inventory Valuation Report | Inventory reports | FR-RPT-036, FR-RPT-052 |
| 50 | Stock Count Variance Report | Inventory reports | FR-RPT-037 |
| 51 | Stock Adjustment Report | Inventory reports | FR-RPT-038 |
| 52 | Purchase Summary | Purchasing reports | FR-RPT-039, FR-RPT-010 |
| 53 | Purchase by Supplier | Purchasing reports | FR-RPT-040, FR-RPT-010 |
| 54 | Purchase Return Report | Purchasing reports | FR-RPT-041 |
| 55 | Purchase Price History — cost-sensitive | Purchasing reports | FR-RPT-042 |
| 56 | Customer Outstanding Report | Credit and collection reports | FR-RPT-043, FR-RPT-011 |
| 57 | Customer Aging Report | Credit and collection reports | FR-RPT-044, FR-RPT-052 |
| 58 | Customer Statement | Credit and collection reports | FR-RPT-045, FR-RPT-011 |
| 59 | Credit Override Report | Credit and collection reports | FR-RPT-046 |
| 60 | Customer data — masked by default | Credit and collection reports | FR-RPT-011, FR-RPT-060 |
| 61 | Management Daily Summary | Management summary | FR-RPT-047, FR-RPT-014 |
| 62 | Exception Highlights | Management summary | FR-RPT-048, FR-RPT-026, FR-RPT-028 |
| 63 | Comparative Periods — optional | Management summary | FR-RPT-049 |
| 64 | Export dialog — format and scope | Export and print | FR-RPT-057, FR-RPT-058 |
| 65 | Export — permission required | Export and print | FR-RPT-059 |
| 66 | Export job — queued and running | Export and print | FR-RPT-057 |
| 67 | Export job — completed, hand off to Export Center | Export and print | FR-RPT-057, FR-RPT-058 |
| 68 | Export job — failed and cancelled | Export and print | FR-RPT-062 |
| 69 | Export — outcome unknown (recovery) | Export and print | FR-RPT-057, FR-RPT-062 |
| 70 | Export — personal data minimised | Export and print | FR-RPT-060, FR-RPT-059 |
| 71 | Print preview | Export and print | FR-RPT-056 |
| 72 | Report access and export audit notice | Export and print | FR-RPT-061 |
| 73 | Central report — incomplete sync warning | Central and later phase | FR-RPT-054, FR-RPT-055 |
| 74 | Report components | Design system and documentation | FR-RPT-050 |
| 75 | Accessibility and keyboard behaviour | Design system and documentation | FR-RPT-001 |
| 76 | Responsive behaviour | Design system and documentation | FR-RPT-015 |
| 77 | Requirement to screen index | Design system and documentation | FR-RPT-001 |
| 78 | Open decisions and authority gaps | Design system and documentation | FR-RPT-063, FR-RPT-065 |
| 79 | Boundaries — what this package does not define | Design system and documentation | FR-RPT-064, FR-RPT-001 |
| 80 | Documentation — confirmations | Design system and documentation | FR-RPT-001, FR-RPT-064 |
