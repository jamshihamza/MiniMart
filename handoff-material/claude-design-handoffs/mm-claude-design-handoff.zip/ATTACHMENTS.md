# Attachment list for Claude Design

Attach in this order. Frozen authority first; the candidate last. Paths are relative to this folder (`D:/mm-cd-handoff`, also zipped as `mm-claude-design-handoff.zip`). File hashes are in `SHA256SUMS.txt`.

## A. Brief

1. `PROMPT.md` (paste the section below the line as the prompt)
2. `DECISIONS-AND-GAPS.md`
3. `COVERAGE-CHECKLIST.md`

## B. Frozen authority (do not alter; copied byte-for-byte except two generated extracts)

| File | Source in the repository |
| --- | --- |
| `authority/01-FRS-reporting-FR-RPT-001-065.md` | `docs/specifications/01-business-and-functional/docs/02-functional/14-reporting/reporting.md` |
| `authority/02-UI-RPT-001..005-*.md` | `docs/specifications/06-ui-specification/screens/UI-RPT-001..005` |
| `authority/02-UI-EXP-001-export-center.md` | `.../screens/UI-EXP-001-export-center.md` |
| `authority/03-API-read-query-reporting.md` | `docs/specifications/05-api-contracts/docs/06-READ-QUERY-REPORTING.md` |
| `authority/04-API-import-export-job-artifact.md` | `.../docs/16-IMPORT-EXPORT-JOB-ARTIFACT.md` |
| `authority/05-API-idempotency-concurrency-recovery.md` | `.../docs/03-IDEMPOTENCY-CONCURRENCY-RECOVERY.md` |
| `authority/06-API-schemas-and-operations-EXTRACT.md` | **generated verbatim extract** of `registry/operations-v1.0.json` and `openapi/minimart-store-node-v1.yaml` |
| `authority/07..14-UI-*.md` | UI spec docs 17, 18, 20, 21, 11, 07, 24, 10 |
| `authority/15-ARCH-read-query-architecture.md` | `docs/specifications/04-architecture/docs/20-READ-QUERY-ARCHITECTURE.md` |
| `authority/16-DOMAIN-credit-cash-accounting.md` | `docs/specifications/02-domain-model/docs/06-CREDIT-CASH-ACCOUNTING.md` |
| `authority/17-DOMAIN-decision-seam-matrix.md` | `.../02-domain-model/docs/13-DECISION-SEAM-MATRIX.md` |
| `authority/18-DECISION-REGISTER.md` | `.../01-business-and-functional/docs/02-functional/DECISION-REGISTER.md` |
| `authority/19-design-handoff-README.md`, `20-design-manifest.schema.json` | `docs/design/` |
| `authority/21-AGENTS.md` | `AGENTS.md` |
| `authority/22-BACKLOG-EPIC-07-extract.md` | **generated verbatim extract** of `docs/backlog/docs/04-BACKLOG-CATALOG.md` EPIC-07 |

## C. Approved visual reference and design-system base

| File | Status |
| --- | --- |
| `approved-references/accounting/MiniMartAccountingLite.dc.html` (+ `support.js`) | `approved-visual-reference`, source SHA-256 `ebe8ca7f38b9b9d5cd9c16fed421bfe5f5863653ec9478a081d368d2bb9df12e` |
| `approved-references/accounting/*.png` | rendered previews 01, 13, 20, 38, 55 at 1366x768 |
| `approved-references/design-system-base/MiniMartBackOffice.dc.html` | `review-ready`, **not approved**; design-system base only |

Other approved packages (Procurement, Customers + Credit, Cash / Business Day) are in the repository under `docs/design/<package>/source/`. Attach them only if you need more patterns; they are not needed to start.

## D. Candidate (input only, never authority)

| File | Notes |
| --- | --- |
| `candidate-INPUT-ONLY/MiniMartReports.dc.html` | Claude Code candidate, **not** a Claude Design export, **not** approved |
| `candidate-INPUT-ONLY/CANDIDATE-SCREEN-LIST.md` | 80-screen coverage list with requirement IDs |
| `candidate-INPUT-ONLY/traceability.json`, `TRACEABILITY.md`, `design-manifest.json` | candidate traceability and manifest |
| `candidate-INPUT-ONLY/renders/*.png` | 12 sample renders at 1366x768 |

## E. Do not attach

`Incoming/`, `Mockups/`, anything under the original Office-PC checkout's staged work, MM-007 / POS / printer material, credentials or `.env` files.
