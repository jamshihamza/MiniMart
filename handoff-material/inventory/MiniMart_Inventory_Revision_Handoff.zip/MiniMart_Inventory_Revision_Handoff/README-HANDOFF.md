# Inventory revision brief for Claude Design

You are revising the MiniMart Inventory package you exported as `MiniMart_Inventory_ClaudeDesign_Source.zip`
(SHA-256 `f476c65607aae2507cf3fb9ada3b988915f35e627eecb5ae9e846cd17b998589`; source `MiniMartInventory.dc.html`
SHA-256 `a18dc6c21a64cfb77056d222fe948e55a67800122acf31469cd20f826ca76479`). An independent integration review
rendered every screen and read it against the frozen authority. Start with `VALIDATION-REPORT.md`, then
`TRACEABILITY.md`. This is a revision, not a rebuild: keep the 60 screens, their numbers and titles, the five grouped
pages, the index, the six print variants and the Back Office shell.

## Rules

1. Frozen authority wins. The files in `authority/` and `guidelines/` are verbatim copies. Do not invent a rule,
   permission code, API operation, field, policy or decision. If the authority is silent, keep the item as a labelled
   open or authority-dependent example, as screen 48 does for count concurrency.
2. Do not resolve DEC-INV-003, 004, 005, 007 (OPEN) or DEC-INV-008 (PROPOSED).
3. Status stays review-ready. Do not describe the package as approved.
4. Keep every existing screen number and title. Where a requirement needs a new state, add a screen at the end (61+) and
   list it, or extend an existing screen; do not renumber.
5. Deliver the same export format: the source, grouped pages, index, six print variants, `support.js`, `doc-page.js`, an
   export manifest with SHA-256 of every packaged file, and a statement of what changed and what you did not verify.
6. Say which defects you fixed and which you did not.

## Corrections requested (design defects, type D in the report)

| ID | Correction | How the reviewer will check it |
| --- | --- | --- |
| F1 | Make the ledger consistent with the Phase-1 negative-stock BLOCK (FR-INV-012, 085, 101; DEC-INV-006, 010). No posted movement may leave a negative running balance. Either remove the -3 row and ADJ-2026-00030 effect, or give the negative balance an origin that the authority defines; do not invent one. Keep a way to list negative items (FR-INV-023), for example a Negative filter. | Screens 02, 16, 17, 20, 21 agree; running balances never go below zero after a Phase-1 posting. |
| F2 | Make the "Counts In Progress" tile equal a defined subset of the count list on screen 30. | Tile value derivable from screen 30. |
| F3 | Make count variance data and references consistent across 16, 30, 43, 46 and 47 (one reference scheme, matching net variance, movement time not before posting time). | Same count reference, variance and times on every screen. |
| F4 | Make batch history on 11 and 12 reconcile to the item ledger on 09 and 16. | Batch totals equal item on-hand and include every adjustment. |
| F10 | Use real form controls (`input`, `select`, `textarea`, `button`) with visible labels, real `table` elements with caption and column headers, one `h1` per screen, live regions for blocked, uncertain and error states, and dialog or drawer semantics for the movement and batch drawers. Show an editable counted-quantity entry on 33, 35, 36 and 50 and field errors tied to fields. Stock count posting must be completable by keyboard. | Structure audit finds controls, tables, headings and live regions; keyboard run completes a count. |
| F11 | Fix clipped tables at 1366x768, 1368x800 and 1280x720 (screens 02, 03, 04, 06, 07, 16, 30, 49) with a layout that fits or an explicit, visible horizontal-scroll treatment; fix the "Negative (historical)" pill overflow. The Back Office target is 1366x768 and above. | No clipped text or hidden columns at the four sizes. |
| F12 | Raise every text/background pair to 4.5:1 (sidebar footer note and group labels, placeholder, muted headings and meta text, "Restricted"). Fix the "New Stock Count" button so its background is applied on screens 02, 03, 04, 06 and 49; keep status from relying on colour alone. | 0 failing pairs; button readable. |
| F13 | Make grouped-page titles equal the source registry titles (08, 09, 11, 25, 26, 60). | Titles identical. |
| F14 | Either bundle a Back Office index link target or mark the link as a cross-package reference; do not leave an unexplained dead link. | Link resolves or is clearly labelled. |
| F15 | Put the documentation (confirmations, changelog, open decisions) where the manifest says it is, or correct the manifest. | Manifest matches the package. |
| F16 | Do not call Back Office "approved" unless the repository says so; in the repository only accounting, cash-shifts, customers, procurement and reports are approved visual references. | Wording matches. |
| F17 | Add the requirement identifier (FR-INV, UI-INV, DEC-INV) to each screen or to a traceability table so coverage can be checked. Use `TRACEABILITY.md` as the starting map; correct it where it is wrong. | Every screen lists the identifiers it serves. |
| F8 | Add the missing states required by `guidelines/17-SCREEN-STATE-CONTRACT.md`: LOADING (skeleton), EMPTY (with a next action), CONFLICT (stale version / STOCK_CHANGED) and INCOMPATIBLE_CLIENT, and field-level VALIDATION_ERROR and PERMISSION_DENIED. | Each state has a screen or an explained omission. |

## Not yours to decide (owner or authority questions)

Show these only as labelled `GAP` or `OPEN` notes. Do not invent the missing pieces.

- F5 display precision of cost and quantity (FR-INV-007, FR-INV-093): the frozen UI contract gives no display scale.
- F6 approve/reject adjustment, count approval, cancel count, opening stock and cost visibility have no frozen operation or permission code (`authority/API-INV-operations.md`). Keep the screens only if each is clearly labelled as depicting an undefined flow.
- F7 UI-INV-006 Reorder / Low Stock: add a screen only as decision support that does not invent reorder ownership (DEC-INV-007).
- F9 expiry availability (DEC-INV-005): do not choose FEFO or expiry handling.
- FR-INV-009, 010, 011 and 013 (allow, warn, approval modes and per-operation policy) conflict with DEC-INV-002 and DEC-INV-010, which resolve Phase 1 to BLOCK. Do not draw the other modes as active.

## Contents of this bundle

- `VALIDATION-REPORT.md`, `TRACEABILITY.md`, `traceability.json` - the review results.
- `guidelines/` - the repository design guidance (verbatim): design system, keyboard, responsive, screen-state, command/recovery, money/quantity, accessibility matrix, document lifecycle, and `docs/design/README.md`.
- `authority/` - exact FR-INV excerpts, DEC-INV rows, the API-INV operation and permission table, and UI-INV-001..006 screen specifications.
- `evidence/` - screenshots of the defects.
