# Evidence screenshots

- `02-inventory-populated-list.png` - F11 F12 clipped columns, invisible New Stock Count button, pill overflow
- `49-inventory-list-1280-720.png` - F11 the 1280x720 reference screen clips
- `16-movement-history-store-wide.png` - F1 F3 ledger rows (running -3; CNT/ADJ references)
- `33-count-entry-standard.png` - F10 no counted-quantity input
- `18-new-adjustment.png` - F10 form fields are not form controls
- `22-adjustment-approval-required.png` - F6 approval flow without a frozen operation
- `43-count-posted.png` - F3 variance movement references
- `MiniMart_Inventory_Mockups_dc_html.png` - F14 index
