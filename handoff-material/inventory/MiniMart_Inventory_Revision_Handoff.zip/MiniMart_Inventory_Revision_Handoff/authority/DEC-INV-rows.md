# DEC-INV rows copied from the frozen Decision Register

Source: `docs/specifications/01-business-and-functional/docs/02-functional/DECISION-REGISTER.md`. Lines as in the file; statuses must not be changed or resolved by the design.

```text
  ID / topic             Status                 v0.9 baseline
  ---------------------- ---------------------- ------------------------
  `DEC-INV-001`          RESOLVED               Moving weighted-average
                                                cost per Item per Store.
...
                                                rules.

  `DEC-INV-006`          RESOLVED               Phase-1 negative stock
                                                blocked; later
                                                negative-stock costing
                                                requires separate
...
                                                claim.

  `DEC-INV-010`          RESOLVED               Phase-1 default
                                                negative-stock behavior
                                                is BLOCK under the
                                                initial WAC baseline.
  ----------------------------------------------------------------------

...
  `DEC-INV-002`   RESOLVED for    Negative stock blocked Later
                  Phase 1         initially; later       negative-stock
                                  configurable modes     feature
                                  require separate       
                                  approval.              

  `DEC-INV-003`   OPEN            Stock-count            Count
                                  concurrency: scope     implementation
                                  lock vs                
                                  snapshot/movement      
                                  reconciliation.        

  `DEC-INV-004`   OPEN            Batch physical         Batch-aware POS
                                  depletion policy.      

  `DEC-INV-005`   OPEN            Expiry/FEFO behavior.  Batch-aware POS

  `DEC-INV-007`   OPEN            Low-stock/reorder      Inventory UI/domain
                                  threshold ownership.   extension

  `DEC-INV-008`   PROPOSED        Opening stock through  Store
                                  controlled audited     migration/go-live
                                  posting.               

  `DEC-INV-009`   RESOLVED        Inventory valuation    Reporting
                                  report belongs in      implementation
                                  Phase 2 reporting.     
  --------------------------------------------------------------------------
```

## Seam matrix rows (what the design must not choose)

```text
  DEC-INV-003    OPEN           DOMAIN/DB HANDOFF       StockCountConcurrencyPolicy; v0.2     Do not choose lock vs
  DEC-INV-004    OPEN           DOMAIN POLICY           BatchSelectionPolicy                  Do not choose physical
  DEC-INV-005    OPEN           DOMAIN POLICY           Expiry/FEFOPolicy                     Do not assume FEFO
  DEC-INV-007    OPEN           DOMAIN EXTENSION        ReorderPolicy boundary only           Do not assign threshold
  DEC-INV-008    PROPOSED       APPLICATION/DOMAIN      OpeningStockPostingPolicy             Do not bypass audited
```
