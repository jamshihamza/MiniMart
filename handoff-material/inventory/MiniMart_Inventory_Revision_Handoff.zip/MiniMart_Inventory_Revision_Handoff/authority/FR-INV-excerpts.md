# Exact FR-INV excerpts for the listed corrections

Copied verbatim from the frozen Inventory FRS (`docs/specifications/01-business-and-functional/docs/02-functional/07-inventory/`). Read-only. Priority and phase are as frozen.

## F1 negative stock and ledger

<!-- FR-INV-008 from inventory.md -->
### FR-INV-008 --- Negative stock policy

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

MiniMart shall support a configurable policy for transactions that would
create negative stock.

**Acceptance:** Policy outcome is explicit.

<!-- FR-INV-009 from inventory.md -->
### FR-INV-009 --- Negative stock allow mode

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

Policy may allow negative stock without blocking while making negative
state visible.

**Acceptance:** Negative quantity is reportable.

<!-- FR-INV-010 from inventory.md -->
### FR-INV-010 --- Negative stock warn mode

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

Policy may warn before permitting a transaction that creates negative
stock.

**Acceptance:** User sees warning.

<!-- FR-INV-011 from inventory.md -->
### FR-INV-011 --- Negative stock approval mode

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

Policy may require authorized manager approval before permitting
negative stock.

**Acceptance:** Approver is audited.

<!-- FR-INV-012 from inventory.md -->
### FR-INV-012 --- Negative stock block mode

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

Policy may block a transaction that would create negative stock.

**Acceptance:** Blocked operation creates no stock effect.

<!-- FR-INV-013 from inventory.md -->
### FR-INV-013 --- Negative stock by operation

**Source:** BR-INV-004\
**Priority:** SHOULD\
**Phase:** 1

MiniMart should permit policy differences by operation type, such as POS
sale versus stock adjustment/purchase return.

**Acceptance:** Policy is deterministic.

<!-- FR-INV-023 from inventory.md -->
### FR-INV-023 --- Negative-stock reportability

**Source:** BR-INV-009\
**Priority:** MUST\
**Phase:** 1

Negative stock shall be explicitly reportable.

**Acceptance:** All negative items can be listed.

<!-- FR-INV-030 from inventory.md -->
### FR-INV-030 --- Inventory history immutability

**Source:** BR-DATA-001, BR-DATA-002\
**Priority:** MUST\
**Phase:** 1

Posted stock history shall not be rewritten to hide/alter prior business
effects; correction uses new traceable movement.

**Acceptance:** Original movement remains visible.

<!-- FR-INV-051 from stock-movement.md -->
### FR-INV-051 --- Movement cannot be directly edited

**Source:** BR-DATA-002\
**Priority:** MUST\
**Phase:** 1

A posted movement shall not be directly edited to change stock.

**Acceptance:** Correction creates compensating movement.

<!-- FR-INV-085 from stock-count-adjustment.md -->
### FR-INV-085 --- Adjustment negative-stock check

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1

A negative adjustment shall apply configured negative-stock policy
before posting.

**Acceptance:** Policy is enforced.

<!-- FR-INV-101 from inventory-costing.md -->
### FR-INV-101 --- Negative stock costing boundary

**Source:** BR-INV-004\
**Priority:** MUST\
**Phase:** 1/2

The initial WAC baseline assumes stock-affecting issues do not take
on-hand quantity below zero. Phase-1 default shall therefore block
negative stock.

If a later policy enables negative stock, its valuation/reconciliation
algorithm shall be specified as a separate approved costing extension
before activation.

**Acceptance:** Phase-1 WAC has no undefined negative-balance
calculation path.

## F2/F3 counts and variance

<!-- FR-INV-039 from stock-movement.md -->
### FR-INV-039 --- Stock count variance movement

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

Posting approved stock-count variance shall create adjustment
movement(s) rather than rewrite history.

**Acceptance:** Variance traces to count.

<!-- FR-INV-050 from stock-movement.md -->
### FR-INV-050 --- Movement reference

**Source:** BR-INV-003\
**Priority:** MUST\
**Phase:** 1

Users shall be able to navigate from movement history to source business
document where applicable.

**Acceptance:** Source is accessible.

<!-- FR-INV-064 from stock-count-adjustment.md -->
### FR-INV-064 --- Expected quantity

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

MiniMart shall determine system quantity against which a count is
compared using a defined count timing/concurrency rule.

**Acceptance:** Expected quantity basis is explicit.

<!-- FR-INV-065 from stock-count-adjustment.md -->
### FR-INV-065 --- Variance calculation

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

MiniMart shall calculate variance between expected and counted quantity.

**Acceptance:** Variance sign/value are clear.

<!-- FR-INV-068 from stock-count-adjustment.md -->
### FR-INV-068 --- Count review

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

A count shall be reviewable before variance is posted.

**Acceptance:** Review shows expected, counted and variance.

<!-- FR-INV-069 from stock-count-adjustment.md -->
### FR-INV-069 --- Count approval

**Source:** BR-INV-007\
**Priority:** MUST\
**Phase:** 1

Posting material count variances shall require applicable permission and
configured approval thresholds.

**Acceptance:** Approver is retained when required.

<!-- FR-INV-070 from stock-count-adjustment.md -->
### FR-INV-070 --- Count posting

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

Posting an approved count shall create explicit adjustment movements for
accepted variance.

**Acceptance:** No direct balance overwrite.

<!-- FR-INV-071 from stock-count-adjustment.md -->
### FR-INV-071 --- Count zero variance

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

A completed count with zero variance shall be recordable without
unnecessary stock movement.

**Acceptance:** Count history remains.

<!-- FR-INV-072 from stock-count-adjustment.md -->
### FR-INV-072 --- Count cancellation

**Source:** BR-INV-006\
**Priority:** MUST\
**Phase:** 1

An unposted count may be cancelled by authorized user with reason where
policy requires.

**Acceptance:** Cancellation creates no stock effect.

<!-- FR-INV-073 from stock-count-adjustment.md -->
### FR-INV-073 --- Posted count immutability

**Source:** BR-DATA-002\
**Priority:** MUST\
**Phase:** 1

A posted stock count shall not be edited to change resulting adjustment.

**Acceptance:** Correction requires new count/adjustment.

<!-- FR-INV-077 from stock-count-adjustment.md -->
### FR-INV-077 --- Count user attribution

**Source:** BR-AUD-002\
**Priority:** MUST\
**Phase:** 1

Count entries and final posting shall retain applicable user
attribution.

**Acceptance:** Who counted/reviewed/posted is identifiable.

<!-- FR-INV-078 from stock-count-adjustment.md -->
### FR-INV-078 --- Count audit

**Source:** BR-AUD-001\
**Priority:** MUST\
**Phase:** 1

Material changes, recounts, approval and posting shall be auditable.

**Acceptance:** History is reviewable.

## F4 batch and expiry

<!-- FR-INV-014 from inventory.md -->
### FR-INV-014 --- Batch stock visibility

**Source:** BR-INV-005\
**Priority:** MUST

**Applicability:** Where tracking is enabled/applicable\
**Phase:** 1

For batch-tracked items, authorized users shall be able to view stock by
batch.

**Acceptance:** Batch totals reconcile to item stock.

<!-- FR-INV-015 from inventory.md -->
### FR-INV-015 --- Expiry visibility

**Source:** BR-INV-005\
**Priority:** MUST

**Applicability:** Where tracking is enabled/applicable\
**Phase:** 1

For expiry-tracked items, users shall be able to view expiry information
associated with eligible stock.

**Acceptance:** Expiry is searchable/reportable.

<!-- FR-INV-016 from inventory.md -->
### FR-INV-016 --- Expired stock identification

**Source:** BR-INV-005\
**Priority:** MUST\
**Phase:** 1

MiniMart shall identify expired stock according to configured date
rules.

**Acceptance:** Expired quantity can be reported.

<!-- FR-INV-017 from inventory.md -->
### FR-INV-017 --- Near-expiry identification

**Source:** BR-INV-005\
**Priority:** SHOULD\
**Phase:** 1

MiniMart should identify stock nearing expiry according to configurable
threshold.

**Acceptance:** Near-expiry filter/report is available.

<!-- FR-INV-018 from inventory.md -->
### FR-INV-018 --- Batch identity preservation

**Source:** BR-DATA-007\
**Priority:** MUST\
**Phase:** 1

Later item/master changes shall not destroy historical batch identity on
posted movements.

**Acceptance:** Movement remains understandable.

<!-- FR-INV-045 from stock-movement.md -->
### FR-INV-045 --- Movement batch

**Source:** BR-INV-005\
**Priority:** MUST

**Applicability:** Where tracking is enabled/applicable\
**Phase:** 1

Batch-tracked movement shall identify affected batch.

**Acceptance:** Batch balance can be reconstructed.

<!-- FR-INV-046 from stock-movement.md -->
### FR-INV-046 --- Movement expiry context

**Source:** BR-INV-005\
**Priority:** MUST

**Applicability:** Where relevant\
**Phase:** 1

Expiry context associated with batch stock shall remain traceable
through movements.

**Acceptance:** Expiry history remains understandable.

## F5 precision

<!-- FR-INV-007 from inventory.md -->
### FR-INV-007 --- Quantity precision

**Source:** BR-CAT-006\
**Priority:** MUST\
**Phase:** 1

Inventory quantities shall respect defined quantity precision and UoM
conversion.

**Acceptance:** Invalid fractional movements are rejected.

<!-- FR-INV-093 from inventory-costing.md -->
### FR-INV-093 --- Cost precision

**Source:** BR-PRI-003\
**Priority:** MUST\
**Phase:** 1/2

Inventory cost calculations shall use sufficient exact decimal precision
and defined rounding rules.

**Acceptance:** Calculations are reproducible.

## F6 approval, opening stock, cost visibility

<!-- FR-INV-036 from stock-movement.md -->
### FR-INV-036 --- Opening stock movement

**Source:** BR-INV-001\
**Priority:** MUST\
**Phase:** 1

Initial stock shall be introduced through a controlled opening-stock
process rather than direct balance editing.

**Acceptance:** Opening source is auditable.

<!-- FR-INV-086 from stock-count-adjustment.md -->
### FR-INV-086 --- Adjustment approval threshold

**Source:** BR-INV-007\
**Priority:** SHOULD\
**Phase:** 1

MiniMart shall support manager approval based on configured
quantity/value/reason thresholds.

**Acceptance:** Approval is auditable.

<!-- FR-INV-104 from inventory-costing.md -->
### FR-INV-104 --- Cost access permission

**Source:** BR-SEC-003\
**Priority:** MUST\
**Phase:** 1

Sensitive purchase/inventory cost information shall be visible only to
authorized roles.

**Acceptance:** Cashier access does not imply cost access.

<!-- FR-INV-105 from inventory-costing.md -->
### FR-INV-105 --- Cost override prohibition

**Source:** BR-DATA-001\
**Priority:** MUST\
**Phase:** 1/2

Users shall not directly edit a computed inventory cost balance;
correction must originate from a defined business/revaluation process.

**Acceptance:** No hidden cost edit.

<!-- FR-INV-026 from inventory.md -->
### FR-INV-026 --- Inventory permission

**Source:** BR-SEC-003\
**Priority:** MUST\
**Phase:** 1

Sensitive inventory actions shall require explicit permissions.

**Acceptance:** Unauthorized action creates no stock effect.

## F7 low stock

<!-- FR-INV-021 from inventory.md -->
### FR-INV-021 --- Low-stock extension

**Source:** BR-INV-009\
**Priority:** MUST\
**Phase:** 1

MiniMart shall support a low-stock threshold/reorder indicator suitable
for reporting.

**Acceptance:** Items below threshold are identifiable.

## F9 expiry availability

<!-- FR-INV-016 from inventory.md -->
### FR-INV-016 --- Expired stock identification

**Source:** BR-INV-005\
**Priority:** MUST\
**Phase:** 1

MiniMart shall identify expired stock according to configured date
rules.

**Acceptance:** Expired quantity can be reported.

<!-- FR-INV-017 from inventory.md -->
### FR-INV-017 --- Near-expiry identification

**Source:** BR-INV-005\
**Priority:** SHOULD\
**Phase:** 1

MiniMart should identify stock nearing expiry according to configurable
threshold.

**Acceptance:** Near-expiry filter/report is available.

## F17 identifiers

<!-- FR-INV-001 from inventory.md -->
### FR-INV-001 --- Current stock visibility

**Source:** BR-INV-002\
**Priority:** MUST\
**Phase:** 1

Authorized users shall be able to view current stock for an item in the
applicable store.

**Acceptance:** Displayed stock corresponds to posted stock-affecting
events.

<!-- FR-INV-002 from inventory.md -->
### FR-INV-002 --- Stock traceability

**Source:** BR-INV-001, BR-INV-003\
**Priority:** MUST\
**Phase:** 1

Every inventory change shall be traceable to a defined source business
event/document or controlled adjustment.

**Acceptance:** Current stock can be explained by history.

<!-- FR-INV-003 from inventory.md -->
### FR-INV-003 --- No arbitrary stock edit

**Source:** BR-INV-001\
**Priority:** MUST\
**Phase:** 1

MiniMart shall not provide an ordinary untracked 'set stock quantity'
action outside a defined opening/count/adjustment process.

**Acceptance:** Every correction has source/reason.

