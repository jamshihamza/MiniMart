# API-INV operations and permission codes (frozen registry)

Source: `docs/specifications/05-api-contracts/registry/operations-v1.0.json`. These are the only Inventory operations and permission codes that exist. There is no approve, cancel-count, recount, opening-stock or cost-visibility operation or code; the design must not present them as defined.

| ID | Method | Path | Permission | Idempotent | If-Match | Decision seams | Summary |
| --- | --- | --- | --- | --- | --- | --- | --- |
| API-INV-001 | GET | `/api/v1/inventory/positions` | `inventory.read` | False | False | - | Search current Item×Store inventory positions |
| API-INV-002 | GET | `/api/v1/inventory/positions/{itemId}` | `inventory.read` | False | False | - | Get current inventory position for current Store |
| API-INV-003 | GET | `/api/v1/inventory/movements` | `inventory.read` | False | False | - | Search immutable stock movements |
| API-INV-004 | GET | `/api/v1/inventory/availability/{itemId}` | `inventory.read` | False | False | DEC-INV-004, DEC-INV-005, DEC-POS-003 | Get policy-neutral sale availability snapshot |
| API-INV-005 | GET | `/api/v1/inventory/stock-counts` | `inventory.read` | False | False | - | Search/list stock counts |
| API-INV-006 | POST | `/api/v1/inventory/stock-counts` | `inventory.write` | True | False | DEC-INV-003 | Create stock-count session |
| API-INV-007 | GET | `/api/v1/inventory/stock-counts/{stockCountId}` | `inventory.read` | False | False | - | Get stock count |
| API-INV-008 | PATCH | `/api/v1/inventory/stock-counts/{stockCountId}` | `inventory.write` | True | True | DEC-INV-003 | Update count observations while mutable |
| API-INV-009 | POST | `/api/v1/inventory/stock-counts/{stockCountId}:post` | `inventory.post` | True | False | DEC-INV-003 | Complete stock count through explicit adjustment movements |
| API-INV-010 | POST | `/api/v1/inventory/adjustments` | `inventory.write` | True | False | DEC-INV-008 | Create controlled manual inventory-adjustment draft |
| API-INV-011 | GET | `/api/v1/inventory/adjustments` | `inventory.adjustment.read` | False | False | - | Search manual inventory-adjustment command history |
| API-INV-012 | GET | `/api/v1/inventory/adjustments/{adjustmentId}` | `inventory.adjustment.read` | False | False | - | Get manual inventory-adjustment command |
| API-INV-013 | PATCH | `/api/v1/inventory/adjustments/{adjustmentId}` | `inventory.adjustment.edit` | True | True | - | Update mutable inventory-adjustment command |
| API-INV-014 | POST | `/api/v1/inventory/adjustments/{adjustmentId}:post` | `inventory.adjustment.post` | True | False | - | Post adjustment as immutable StockMovement under Inventory module UoW |
| API-INV-015 | POST | `/api/v1/inventory/adjustments/{adjustmentId}:correct` | `inventory.adjustment.correct` | True | False | - | Post compensating correction movement for a posted adjustment |

Error codes on mutations include: AUTHENTICATION_REQUIRED, BUSINESS_RULE_REJECTED, IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST, INCOMPATIBLE_CLIENT, INSUFFICIENT_STOCK, PERMISSION_DENIED, PRECONDITION_FAILED, RESOURCE_NOT_FOUND, SERVICE_UNAVAILABLE, STALE_RESOURCE_VERSION, STOCK_CHANGED, VALIDATION_FAILED.
